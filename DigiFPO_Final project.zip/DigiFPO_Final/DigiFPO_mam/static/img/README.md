# DigiFPO Local Image Assets

This project now uses local original farming/FPO visuals stored in this folder.

Current built-in assets:

1. `digifpo-logo.svg`
   Crop-symbol logo used in the intro, navbar, and footer.

2. `hero-farm.svg`
   Farmer and farm visual used on the home page and farmer dashboard.

3. `market-workflow.svg`
   Farming/FPO scene used on supporting sections and non-farmer dashboards.

4. `hero-transporter.jpg`
   Legacy file kept in the folder, but it is no longer used on the main dashboard pages.

Notes:

- These SVG assets are project-local and can be used freely inside this app.
- No external image download is required for the main UI.
- The app should prefer farmer/FPO-related local visuals instead of third-party stock placeholders.

If more visuals are needed, add new local assets here and reference them through `/static/img/...`.

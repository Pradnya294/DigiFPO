# DigiFPO UI Professionalization TODO
Status: In Progress

## Plan Steps:
- [x] Created this TODO.md
- [x] Step 1: Update custom.css with govt styles (tables, tricolor accents, print)
- [x] Step 2: Update base.html (govt meta, footer disclaimer, Ashoka slot)
- [ ] Step 3: Audit & enhance priority templates (dashboard.html, vote.html, vote_results.html, create_fpo.html)
- [ ] Step 4: Read & fix remaining open tabs (products.html, seller_orders.html, crop.html, bidding.html, etc.)
- [ ] Step 5: Add real images to static/img/, update CSS references
- [ ] Step 6: Test app (`python app.py`), check responsive/accessibility
- [ ] Step 7: Lighthouse audit, finalize

Next: Priority templates (Step 3).

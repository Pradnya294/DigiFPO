import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash


# =========================
# DB CONNECTION (FIXED)
# =========================
DB_PATH = os.path.join(os.path.dirname(__file__), "database.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# =========================
# CREATE TABLES
# =========================
def create_tables():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        role TEXT,
        farm_location TEXT,
        land_area REAL,
        main_crop TEXT,
        business_name TEXT,
        business_type TEXT,
        vehicle_type TEXT,
        service_area TEXT,
        contact TEXT,
        shop_name TEXT,
        seller_location TEXT,
        product_type TEXT,
        fpo_id INTEGER
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS fpo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fpo_name TEXT,
        created_by TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS fpo_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fpo_id INTEGER,
        user_email TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS crops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmer_email TEXT,
        fpo_id INTEGER,
        crop_name TEXT,
        quantity REAL
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS bids (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        buyer_email TEXT,
        fpo_id INTEGER,
        crop_name TEXT,
        price REAL,
        quantity REAL       
    )
            
    """)

    cur.execute("""
CREATE TABLE IF NOT EXISTS votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fpo_id INTEGER,
    buyer_email TEXT,
    crop_name TEXT,
    voter_email TEXT UNIQUE,
    vote_time TEXT
)
""")
    cur.execute("""
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_email TEXT,
    product_name TEXT,
    price REAL,
    quantity REAL
)
    """)

    cur.execute("""

    CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    farmer_email TEXT,
    seller_email TEXT,
    quantity REAL,
    status TEXT DEFAULT 'PENDING',
    order_time TEXT
)
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_email TEXT,
    message TEXT,
    status TEXT DEFAULT 'UNREAD',
    created_at TEXT
)
    """)

    cur.execute("PRAGMA table_info(orders)")
    order_columns = {row[1] for row in cur.fetchall()}

    if "seller_email" not in order_columns:
        cur.execute("ALTER TABLE orders ADD COLUMN seller_email TEXT")

    if "order_time" not in order_columns:
        cur.execute("ALTER TABLE orders ADD COLUMN order_time TEXT")

    cur.execute("""
        UPDATE orders
        SET seller_email = (
            SELECT seller_email
            FROM products
            WHERE products.id = orders.product_id
        )
        WHERE seller_email IS NULL
    """)

    conn.commit()
    conn.close()


# =========================
# USER
# =========================
def get_user_by_email(email):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email=?", (email,))
    data = cur.fetchone()
    conn.close()
    return data


def verify_password(hashed, password):
    return check_password_hash(hashed, password)


def create_user(data):
    conn = get_db()
    cur = conn.cursor()

    hashed_password = generate_password_hash(data.get('password'))

    try:
        cur.execute("""
        INSERT INTO users (
            name, email, password, role,
            farm_location, land_area, main_crop,
            business_name, business_type,
            vehicle_type, service_area, contact,
            shop_name, seller_location, product_type
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.get('name'),
            data.get('email'),
            hashed_password,
            data.get('role'),
            data.get('farm_location'),
            data.get('land_area'),
            data.get('main_crop'),
            data.get('business_name'),
            data.get('business_type'),
            data.get('vehicle_type'),
            data.get('service_area'),
            data.get('contact'),
            data.get('shop_name'),
            data.get('seller_location'),
            data.get('product_type')
        ))

        conn.commit()
    finally:
        conn.close()


# =========================
# FPO
# =========================
def create_fpo(fpo_name, email):
    conn = get_db()
    cur = conn.cursor()

    cur.execute(
        "INSERT INTO fpo (fpo_name, created_by) VALUES (?, ?)",
        (fpo_name, email)
    )

    conn.commit()
    conn.close()


def get_all_fpos():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT id, fpo_name FROM fpo")
    data = cur.fetchall()

    conn.close()
    return data


def join_fpo(fpo_id, email):
    conn = get_db()
    cur = conn.cursor()

    cur.execute(
        "INSERT INTO fpo_members (fpo_id, user_email) VALUES (?, ?)",
        (fpo_id, email)
    )

    cur.execute(
        "UPDATE users SET fpo_id = ? WHERE email = ?",
        (fpo_id, email)
    )

    conn.commit()
    conn.close()


# =========================
# USER FPO
# =========================
def get_user_fpo(email):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT u.fpo_id, f.fpo_name 
        FROM users u 
        LEFT JOIN fpo f ON u.fpo_id = f.id 
        WHERE u.email = ?
    """, (email,))
    data = cur.fetchone()

    conn.close()
    return data  # Returns (fpo_id, fpo_name) or None


def is_user_in_fpo_members(email, fpo_id):
    conn = get_db()
    cur = conn.cursor()
    
    cur.execute(
        "SELECT 1 FROM fpo_members WHERE user_email = ? AND fpo_id = ?",
        (email, fpo_id)
    )
    result = cur.fetchone()
    conn.close()
    return result is not None


# =========================
# CROPS
# =========================
def add_crop(email, fpo_id, crop_name, quantity):
    conn = get_db()
    cur = conn.cursor()



    cur.execute("""
        INSERT INTO crops (farmer_email, fpo_id, crop_name, quantity)
        VALUES (?, ?, ?, ?)
    """, (email, fpo_id, crop_name, quantity))

    conn.commit()
    conn.close()


def get_fpo_crops(fpo_id):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT crop_name, SUM(quantity)
        FROM crops
        WHERE fpo_id = ?
        GROUP BY crop_name
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data


# =========================
# BIDS
# =========================
def add_bid(buyer_email, fpo_id, crop_name, price, quantity):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO bids (buyer_email, fpo_id, crop_name, price, quantity)
        VALUES (?, ?, ?, ?, ?)
    """, (buyer_email, fpo_id, crop_name, price, quantity))

    conn.commit()
    conn.close()

def get_bids_by_fpo(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT buyer_email, crop_name, price, quantity
        FROM bids
        WHERE fpo_id = ?
        ORDER BY id DESC
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data


def get_fpo_crops_for_bidding(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT crop_name, SUM(quantity)
        FROM crops
        WHERE fpo_id = ?
        GROUP BY crop_name
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data


# =========================
# Aggregation(buyer)
# =========================


def get_all_crops_aggregation():

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT 
            fpo.fpo_name,
            crops.crop_name,
            SUM(crops.quantity)
        FROM crops
        JOIN fpo ON crops.fpo_id = fpo.id
        GROUP BY fpo.fpo_name, crops.crop_name
    """)

    data = cur.fetchall()
    conn.close()
    return data


# =========================
# Aggregation (farmer)
# =========================
def get_fpo_farmer_crop_details(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT 
            users.name AS farmer_name,
            crops.crop_name AS crop_name,
            SUM(crops.quantity) AS total_quantity
        FROM crops
        JOIN users ON crops.farmer_email = users.email
        WHERE crops.fpo_id = ?
        GROUP BY users.name, crops.crop_name
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data


# =========================
# get_fpo_crops_with_name (fix)
# =========================
def get_fpo_crops_with_name(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT 
            fpo.fpo_name,
            crops.crop_name,
            SUM(crops.quantity)
        FROM crops
        JOIN fpo ON crops.fpo_id = fpo.id
        WHERE crops.fpo_id = ?
        GROUP BY crops.crop_name
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data


# =========================
# get_all_crops (fix)
# =========================
def get_all_crops():

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT 
            fpo.fpo_name,
            crops.crop_name,
            SUM(crops.quantity)
        FROM crops
        JOIN fpo ON crops.fpo_id = fpo.id
        GROUP BY crops.fpo_id, crops.crop_name
    """)

    data = cur.fetchall()
    conn.close()
    return data

def get_crop_fpo_id(crop_name):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT fpo_id
        FROM crops
        WHERE crop_name = ?
        LIMIT 1
    """, (crop_name,))

    result = cur.fetchone()
    conn.close()

    return result[0] if result else None


# =========================
# Voting
# =========================
from datetime import datetime

def add_vote(fpo_id, buyer_email, crop_name, voter_email):

    conn = get_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO votes (fpo_id, buyer_email, crop_name, voter_email, vote_time)
            VALUES (?, ?, ?, ?, ?)
        """, (fpo_id, buyer_email, crop_name, voter_email, datetime.now()))
        conn.commit()
    finally:
        conn.close()

def has_voted(fpo_id, voter_email):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT 1 FROM votes
        WHERE fpo_id = ? AND voter_email = ?
    """, (fpo_id, voter_email))

    result = cur.fetchone()
    conn.close()

    return result is not None

def get_bids_for_voting(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT buyer_email, crop_name, price, quantity
        FROM bids
        WHERE fpo_id = ?
        ORDER BY price DESC
    """, (fpo_id,))

    data = cur.fetchall()
    conn.close()
    return data
def get_vote_results(fpo_id):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT buyer_email, crop_name, COUNT(*) as total_votes
        FROM votes
        WHERE fpo_id = ?
        GROUP BY buyer_email, crop_name
        ORDER BY total_votes DESC
    """, (int(fpo_id),))

    data = cur.fetchall()
    conn.close()

    return data

#SELLER ADDS PRODUCT

def add_product(seller_email, name, price, quantity):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO products (seller_email, product_name, price, quantity)
        VALUES (?, ?, ?, ?)
    """, (seller_email, name, price, quantity))

    conn.commit()
    conn.close()

#FARMER VIEWS PRODUCTS
def get_all_products(seller_email=None):

    conn = get_db()
    cur = conn.cursor()

    if seller_email:
        cur.execute("""
            SELECT id, product_name, price, quantity, seller_email
            FROM products
            WHERE seller_email = ?
            ORDER BY id DESC
        """, (seller_email,))
    else:
        cur.execute("""
            SELECT id, product_name, price, quantity, seller_email
            FROM products
            ORDER BY id DESC
        """)

    data = cur.fetchall()
    conn.close()

    return data

#FARMER PLACES ORDER

def place_order(product_id, farmer_email, quantity):

    conn = get_db()
    cur = conn.cursor()

    try:
        cur.execute("SELECT seller_email FROM products WHERE id = ?", (product_id,))
        seller_row = cur.fetchone()
        if not seller_row:
            return False

        seller = seller_row[0]

        cur.execute("""
            INSERT INTO orders (product_id, farmer_email, seller_email, quantity, status, order_time)
            VALUES (?, ?, ?, ?, 'PENDING', ?)
        """, (product_id, farmer_email, seller, quantity, datetime.now()))

        conn.commit()
        return True
    finally:
        conn.close()

#Seller Accept /reject

def update_order(order_id, status):

    conn = get_db()
    cur = conn.cursor()

    # update order
    cur.execute("""
        UPDATE orders
        SET status = ?
        WHERE id = ?
    """, (status, order_id))

    conn.commit()

    # get farmer email
    cur.execute("SELECT farmer_email FROM orders WHERE id = ?", (order_id,))
    farmer = cur.fetchone()[0]

    conn.close()

    return farmer

#Notification system

from datetime import datetime

def add_notification(email, message):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO notifications (user_email, message, status, created_at)
        VALUES (?, ?, 'UNREAD', ?)
    """, (email, message, datetime.now()))

    conn.commit()
    conn.close()


def get_notifications_for_user(email):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT id, message, status, created_at
        FROM notifications
        WHERE user_email = ?
        ORDER BY created_at DESC
    """, (email,))

    data = cur.fetchall()
    conn.close()
    return data


def update_transporter_profile(email, vehicle_type, service_area, contact):

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        UPDATE users
        SET vehicle_type = ?, service_area = ?, contact = ?
        WHERE email = ?
    """, (vehicle_type, service_area, contact, email))

    conn.commit()
    conn.close()

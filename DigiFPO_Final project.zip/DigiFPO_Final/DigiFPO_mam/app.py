import sqlite3
from flask import Flask, g, redirect, render_template, request, session
from controller import (
    add_crop_controller,
    create_fpo_controller,
    join_fpo_controller,
    register_user,
    login_user,
    view_bids_controller,
    place_bid_controller,
    get_available_crops,
    vote_controller,
    view_bids_for_voting_controller,
    has_voted,
    vote_results_controller,
    view_farmer_fpo_crops_controller,
    view_all_crops_controller,
    view_market_crops_controller
)
from models import (
    add_notification,
    add_product,
    create_tables,
    get_all_fpos,
    get_all_products,
    get_db,
    get_notifications_for_user,
    get_user_fpo,
    get_fpo_crops,
    place_order,
    update_transporter_profile,
    update_order,

)

app = Flask(__name__)
import secrets
app.secret_key = secrets.token_hex(16)

# =========================
# INIT DB
# =========================
create_tables()




# =========================
# LOGIN DECORATOR
# =========================
def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect('/login')
        
        # Fetch full user data
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],))
        user_row = cur.fetchone()
        conn.close()
        
        if user_row:
            g.user = dict(user_row)
        else:
            return redirect('/login')
        
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper




# =========================
# BASIC ROUTES
# =========================
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        result = register_user(request.form)
        if isinstance(result, str):
            return render_template('register.html', message=result)
        return redirect('/login')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        result = login_user(request.form)

        if isinstance(result, str):
            return render_template('login.html', error=result)

        session['user_id'] = result[0]
        session['email'] = result[2]
        role = result[4]
        session['role'] = role

        if role == "farmer":
            return redirect('/farmer_dashboard')
        elif role == "buyer":
            return redirect('/buyer_dashboard')
        elif role == "seller":
            return redirect('/seller')
        elif role == "transporter":
            return redirect('/transporter_dashboard')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


# =========================
# DASHBOARD
# =========================



@app.route('/buyer_dashboard')
@login_required
def buyer_dashboard():
    return render_template('dashboard.html', role="Buyer")




@app.route('/transporter_dashboard')
@login_required
def transporter_dashboard():
    return render_template('dashboard.html', role="Transporter")


# =========================
# FPO MODULE
# =========================
@app.route('/create_fpo', methods=['GET', 'POST'])
@login_required
def create_fpo_page():
    if request.method == 'POST':
        msg = create_fpo_controller(request.form, session['email'])
        return render_template('create_fpo.html', message=msg)

    return render_template('create_fpo.html')


@app.route('/join_fpo', methods=['GET', 'POST'])
@login_required
def join_fpo_page():
    fpos = get_all_fpos()

    if request.method == 'POST':
        msg = join_fpo_controller(request.form, session['email'])
        if "success" in msg.lower():
            return redirect('/farmer_dashboard')
        return render_template('join_fpo.html', fpos=fpos, message=msg)

    return render_template('join_fpo.html', fpos=fpos)


@app.route('/farmer_dashboard')
@login_required
def farmer_dashboard():
    from models import get_user_fpo
    user_fpo = get_user_fpo(g.user['email'])
    fpo_name = user_fpo[1] if user_fpo and user_fpo[1] else None
    
    return render_template('dashboard.html', role="Farmer", fpo_name=fpo_name, user=g.user)


# =========================
# VIEW CROPS
# =========================
@app.route('/crop', methods=['GET'])
@login_required
def crop():

    fpo = get_user_fpo(session['email'])

    if not fpo:
        return "Join an FPO first"

    fpo_id = fpo[0]

    data = get_fpo_crops(fpo_id)

    return render_template('crop.html', data=data)


# =========================
# ADD CROP
# =========================
@app.route('/add_crop', methods=['POST'])
@login_required
def add_crop_route():
    add_crop_controller(request.form, session['email'])
    return redirect('/crop')


# =========================
# view CROP
# =========================
from controller import view_farmer_fpo_crops_controller
@app.route('/my_crops', methods=['GET'])
@login_required
def view_crops():

    email = session['email']

    data = view_farmer_fpo_crops_controller(email)

    return render_template(
        'view_crops.html',
        data=data,
        page_title="My FPO crop details",
        page_description="See how each farmer in your FPO is contributing to the current crop pool.",
        columns=["Farmer name", "Crop name", "Total quantity"],
        empty_message="No crop records are available for your FPO yet.",
        back_href="/farmer_dashboard"
    )

# =========================
# view CROP Buyer
# =========================

from controller import view_all_crops_controller

@app.route('/market_crops')
@login_required
def view_crops_all():

    data = view_all_crops_controller()

    return render_template(
        'view_crops.html',
        data=data,
        page_title="All listed crops",
        page_description="A quick view of crop supply across FPOs currently using DigiFPO.",
        columns=["FPO name", "Crop name", "Total quantity"],
        empty_message="No crop listings are available yet.",
        back_href="/buyer_dashboard"
    )







# =========================
# Bidding
# =========================
from controller import place_bid_controller,get_available_crops
@app.route('/bidding', methods=['GET', 'POST'])
@login_required
def bidding():

    email = session['email']
    message = None

    if request.method == 'POST':
        message = place_bid_controller(request.form, email)

    crops = get_available_crops(email)
    bids = view_bids_controller(email)

    return render_template(
        'bidding.html',
        crops=crops,
        bids=bids,
        message=message
    )





# =========================
#aggregation
# =========================
from controller import view_market_crops_controller

@app.route('/aggrigation')
@login_required
def aggregation():

    data = view_market_crops_controller()

    return render_template(
        'view_crops.html',
        data=data,
        page_title="Aggregated market crops",
        page_description="Compare grouped crop availability across FPOs before placing bids.",
        columns=["FPO name", "Crop name", "Total quantity"],
        empty_message="No aggregated crop data is available yet.",
        back_href="/buyer_dashboard"
    )


# =========================
#VOTING
# =========================

from controller import vote_controller,view_bids_for_voting_controller,has_voted
@app.route('/vote', methods=['GET', 'POST'])
@login_required
def vote():

    email = session['email']
    message = None

    fpo = get_user_fpo(email)
    fpo_id = fpo[0] if fpo else None

    if request.method == 'POST':
        message = vote_controller(request.form, email)

    bids = view_bids_for_voting_controller(email)

    voted = has_voted(fpo_id, email)   # ✔ per farmer check

    return render_template(
        'vote.html',
        bids=bids,
        message=message,
        voted=voted,
        fpo_id=fpo_id
    )
from controller import vote_results_controller
@app.route('/vote_results')
@login_required
def vote_results():

    email = session['email']

    data, error = vote_results_controller(email)

    return render_template(
        "vote_results.html",
        data=data,
        error=error
    )


# =========================
# STUB ROUTES
# =========================

@app.route('/seller')
@login_required
def seller_dashboard():

    email = session['email']
    products = get_all_products(email)
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM orders WHERE seller_email = ?", (email,))
    orders_count = cur.fetchone()[0]
    conn.close()

    return render_template("seller.html", products=products, orders_count=orders_count)


@app.route('/add_product', methods=['POST'])
@login_required
def add_product_route():

    email = session['email']

    name = request.form['product_name']
    price = request.form['price']
    quantity = request.form['quantity']

    add_product(email, name, price, quantity)

    return redirect('/seller')

@app.route('/products')
@login_required
def view_products():

    data = get_all_products()   # ✅ correct

    return render_template("products.html", products=data)

@app.route('/place_order', methods=['POST'])
@login_required
def order_route():

    product_id = request.form['product_id']
    quantity = request.form['quantity']
    farmer_email = session['email']

    place_order(product_id, farmer_email, quantity)

    return redirect('/products')

@app.route('/seller_orders')
@login_required
def seller_orders():

    email = session['email']

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT orders.id, products.product_name, orders.farmer_email, orders.quantity, orders.status
        FROM orders
        LEFT JOIN products ON orders.product_id = products.id
        WHERE orders.seller_email = ?
        ORDER BY orders.id DESC
    """, (email,))

    data = cur.fetchall()
    conn.close()

    return render_template("seller_orders.html", orders=data)


@app.route('/notifications')
@login_required
def notifications():

    data = get_notifications_for_user(session['email'])

    return render_template("notification.html", notifications=data)

@app.route('/accept_order/<int:order_id>')
@login_required
def accept_order(order_id):

    farmer = update_order(order_id, "ACCEPTED")

    add_notification(farmer, "Your order has been ACCEPTED")

    return redirect('/seller_orders')


@app.route('/reject_order/<int:order_id>')
@login_required
def reject_order(order_id):

    farmer = update_order(order_id, "REJECTED")

    add_notification(farmer, "Your order has been REJECTED")

    return redirect('/seller_orders')












@app.route('/transporter_dashboard_update', methods=['GET', 'POST'])
@login_required
def transporter_dashboard_update():
    message = None

    if request.method == 'POST':
        update_transporter_profile(
            session['email'],
            request.form.get('vehicle_type'),
            request.form.get('service_area'),
            request.form.get('contact')
        )
        message = "Transport profile updated successfully"

        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM users WHERE id = ?
        """, (session['user_id'],))
        user_row = cur.fetchone()
        conn.close()
        if user_row:
            g.user = dict(user_row)

    return render_template('transporter_update.html', message=message)


# =========================
# RUN APP
# =========================
if __name__ == '__main__':
    app.run(debug=True)

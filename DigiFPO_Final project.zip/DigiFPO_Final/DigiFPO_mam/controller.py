VOTE_DEADLINE_HOURS = 24
import sqlite3
from models import (
    add_notification,
    create_user,
    get_user_by_email,
    update_order,
    verify_password,
    create_fpo,
    join_fpo,
    get_user_fpo,
    add_crop,
    get_fpo_crops,
    add_bid,
    get_bids_by_fpo,
    add_vote,
    get_crop_fpo_id
    
)

# =========================
# REGISTER
# =========================
def register_user(form_data):

    name = form_data.get('name')
    email = form_data.get('email')
    password = form_data.get('password')

    if not name or not email or not password:
        return "All fields required"

    try:
        create_user(form_data)
        return "User registered successfully"
    except sqlite3.IntegrityError:
        return "Email already registered"


# =========================
# LOGIN
# =========================
def login_user(form_data):

    email = form_data.get('email')
    password = form_data.get('password')

    user = get_user_by_email(email)

    if not user:
        return "User not found"

    if not verify_password(user['password'], password):
        return "Invalid password"

    return user


# =========================
# CREATE FPO
# =========================
def create_fpo_controller(form_data, email):

    fpo_name = form_data.get('fpo_name')

    if not fpo_name:
        return "FPO name required"

    create_fpo(fpo_name, email)
    return "FPO created successfully"


# =========================
# JOIN FPO
# =========================
def join_fpo_controller(form_data, email):

    fpo_id = form_data.get('fpo_id')

    if not fpo_id:
        return "Select FPO"

    from models import get_user_by_email, is_user_in_fpo_members
    user = get_user_by_email(email)
    
    if not user or user['role'] != 'farmer':
        return "Only farmers can join FPOs"

    if is_user_in_fpo_members(email, int(fpo_id)):
        return "Already a member of this FPO"

    join_fpo(int(fpo_id), email)
    return "Joined FPO successfully!"


# =========================
# ADD CROP
# =========================
def add_crop_controller(form_data, email):

    crop_name = form_data.get('crop_name')
    quantity = form_data.get('quantity')

    if not crop_name or not quantity:
        return "All fields required"

    fpo = get_user_fpo(email)

    if not fpo or not fpo[0]:
        return "Join an FPO first"

    add_crop(email, fpo[0], crop_name, float(quantity))

    return "Crop added successfully"


# =========================
# VIEW CROPS
# =========================


from models import get_all_crops

def view_all_crops_controller():
    return get_all_crops()


# =========================
# BIDDING
# =========================
from models import (
    add_bid,
    get_bids_by_fpo,
    get_user_fpo,
    get_fpo_crops_for_bidding
)


def place_bid_controller(form_data, email):

    crop_name = form_data.get('crop_name')
    price = form_data.get('price')
    quantity = form_data.get('quantity')

    if not crop_name or not price or not quantity:
        return "All bid fields are required"

    fpo_id = get_crop_fpo_id(crop_name)

    if not fpo_id:
        return "Select a valid crop name from the available list"

    add_bid(email, fpo_id, crop_name, price, quantity)

    return "Bid placed successfully"


def view_bids_controller(email):

    fpo = get_user_fpo(email)

    if not fpo or not fpo[0]:
        return []

    return get_bids_by_fpo(fpo[0])


def get_available_crops(email):

    fpo = get_user_fpo(email)

    if not fpo or not fpo[0]:
        return []

    return get_fpo_crops_for_bidding(fpo[0])
# =========================
# PLACEHOLDERS
# =========================
def view_aggregate_controller(email):
    return "Not implemented"


def view_transport_controller():
    return "Not implemented"

# =========================
# Aggregation(buyer)
# =========================


from models import get_all_crops_aggregation
def view_market_crops_controller():

    return get_all_crops_aggregation()


# =========================
# Aggregation (farmer)
# =========================
from models import get_user_fpo, get_fpo_farmer_crop_details

def view_farmer_fpo_crops_controller(email):

    fpo = get_user_fpo(email)

    if not fpo or not fpo[0]:
        return []

    fpo_id = fpo[0]

    return get_fpo_farmer_crop_details(fpo_id)


# =========================
# Voting
# =========================
from models import has_voted
def vote_controller(form_data, email):

    conn = get_db()
    cur = conn.cursor()

    # get correct fpo_id from user
    cur.execute("SELECT fpo_id FROM users WHERE email = ?", (email,))
    fpo = cur.fetchone()

    if not fpo:
        return "User not in FPO"

    fpo_id = fpo[0]

    buyer_email = form_data.get('buyer_email')
    crop_name = form_data.get('crop_name')
    if not buyer_email or not crop_name:
        return "Select a valid buyer bid before voting"

    try:
        add_vote(fpo_id, buyer_email, crop_name, email)
        return "Vote submitted successfully"
    except sqlite3.IntegrityError:
        return "You have already voted"


def view_bids_for_voting_controller(email):

    from models import get_user_fpo, get_bids_for_voting

    fpo = get_user_fpo(email)

    if not fpo:
        return []

    return get_bids_for_voting(fpo[0])
from models import get_vote_results, get_user_fpo

def vote_results_controller(email):

    fpo = get_user_fpo(email)

    if not fpo:
        return None, "Join an FPO first"

    fpo_id = fpo[0]

    data = get_vote_results(fpo_id)

    return data, None

    return get_vote_results(fpo[0])

from datetime import datetime, timedelta

def is_voting_open(start_time):

    if not start_time:
        return True

    return datetime.now() < start_time + timedelta(hours=VOTE_DEADLINE_HOURS)

from models import get_db


# =========================
# Input seller
# =========================


def accept_order_controller(order_id):

    farmer = update_order(order_id, "ACCEPTED")

    add_notification(farmer, "Your order has been ACCEPTED")

    return "Order Accepted"

def reject_order_controller(order_id):

    farmer = update_order(order_id, "REJECTED")

    add_notification(farmer, "Your order has been REJECTED")

    return "Order Rejected"
